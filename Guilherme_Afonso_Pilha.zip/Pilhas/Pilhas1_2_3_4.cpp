#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


1 - Pilhas s�o estruturas de dados que armazenam os elementos em um formato sequencial, 
empilhando um item acima do outro. Elas podem ser utilizadas em situa��es de desfazer ou refazer em editores de texto
navega��es entre p�ginas na web e tamb�m em fun��es recursivas em compiladores.


2- Uma aloca��o sequencial para um conjunto de elementos, significa alocar a mem�ria de forma cont�gua/adjacente entre seus intervalos

3 - Na aloca��o est�tica o espa�o de mem�ria, que as
vari�veis ir�o utilizar durante a execu��o do programa, �
definido no processo de compila��o. N�o sendo poss�vel
alterar o tamanho desse espa�o durante a execu��o do
programa. 


4 - Na aloca��o din�mica o espa�o de mem�ria, que as
vari�veis ir�o utilizar durante a execu��o do programa, �
definido enquanto o programa est� em execu��o.
	

