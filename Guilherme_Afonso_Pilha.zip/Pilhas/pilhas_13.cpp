#include <iostream>
#include "estrutura_3.h"
#include <cstdlib>

using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//Cabe�alho da funcao:
void comparaPilha(Pilha *P1, Pilha *P2, int quantidade);


void comparaPilha(Pilha *P1, Pilha *P2, int quantidade){
	int contador;
	
	if(P1->topo > P2->topo){
		cout << "A Pilha 1 � maior!! " << endl;
		
	}else if(P1->topo < P2->topo){
		cout << "A Pilha 2 � maior!!" << endl;
		
	}else{
		cout << " As Pilhas s�o do mesmo tamanho!!" << endl;
		for(int i = 0; i < quantidade; i++){
			for(int j = 0; j < quantidade ;j++){
				if(P1->itens[i] == P2->itens[j]){
					contador++;
				}
			}
			
				
			
		}
		if(contador == quantidade){
			cout << "As Pilhas possuem os mesmos elementos!!" << endl;
			
		}else{
			cout << "Os elementos da pilha s�o diferentes !!" << endl;
		}
	}
}

int main() {
	setlocale(LC_ALL,"Portuguese");
	Pilha P1, P2;
	elem X;
	int num_elementos;
	bool erro;
	// Criando as pilhas:
	Create(&P1);
	Create(&P2);
	cout << "Insira a quantidade de elmentos de sua pilha 1: ";
	cin >> num_elementos;
	
	for(int i = 0; i < num_elementos; i++){
		cout << "Insira o elemento: ";
		cin >> X;
		Push(&P1,&X,&erro);
		
		}
	cout << "Insira a quantidade de elmentos de sua pilha 2: ";
	cin >> num_elementos;
	
	for(int i = 0; i < num_elementos; i++){
		cout << "Insira o elemento: ";
		cin >> X;
		Push(&P2,&X,&erro);
		
		}
		
	comparaPilha(&P1, &P2, num_elementos);
	
}
